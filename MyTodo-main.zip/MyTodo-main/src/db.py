from datetime import date

tarefas = [
    {
        "id": 1,
        "nome": "Tarefa Teste",
        "descricao": "Uma tarefa para testar as paradas",
        "data_inicio": date(2024, 3, 13),
        "data_conclusao": None,
        "concluida": False,
    }
]
