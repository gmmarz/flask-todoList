# Minha Lista de Tarefas

Projeto realizado na turma do Super Módulo de Flask da Infinity School iniciada no dia 13/01/2024

Projeto com fim educacional
